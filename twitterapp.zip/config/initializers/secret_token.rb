# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Twitterapp::Application.config.secret_token = 'cc7b029a2d6d2af991953fa6e087f5837066d2e5733f3991b0dffb43f2fe501de7e3f1e698e0bf43f3c18465f003da5008b749f5f3744f4f16ccb520e511c9bb'
